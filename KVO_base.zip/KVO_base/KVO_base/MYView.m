//
//  MYView.m
//  KVO_base
//
//  Created by 谢鑫 on 2019/8/21.
//  Copyright © 2019 Shae. All rights reserved.
//

#import "MYView.h"
@implementation MYView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
//重写mode的set方法
- (void)setMode:(MYMode *)mode{
   _mode=mode;
   self.text=_mode.name;
}

//KVO：模型数据发生变化时调用
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    NSString *newText=change[@"new"];
    self.text=newText;
    NSLog(@"old:%@,new:%@",change[@"old"],change[@"new"]);
}
@end
