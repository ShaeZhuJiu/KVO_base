//
//  ViewController.m
//  KVO_base
//
//  Created by 谢鑫 on 2019/8/21.
//  Copyright © 2019 Shae. All rights reserved.
//

#import "ViewController.h"
#import "MYView.h"
#import "MYMode.h"
@interface ViewController ()
@property (nonatomic,strong)MYMode *myMode;
@property (nonatomic,strong)MYView *myView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.myView];
    //创建数据模型对象
    self.myMode=[[MYMode alloc]init];
    //添加观察者
    [_myMode addObserver:self.myView forKeyPath:@"name" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
}
-(MYView *)myView{
    if (_myView==nil) {
        _myView=[[MYView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
        _myView.backgroundColor=[UIColor redColor];
        _myView.textColor=[UIColor whiteColor];
    }
    return _myView;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    self.myMode.name=[NSString stringWithFormat:@"%u",arc4random_uniform(10000000)]; 
}
@end
